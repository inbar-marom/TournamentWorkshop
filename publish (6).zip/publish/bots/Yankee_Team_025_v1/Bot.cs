
using System.Threading;
using System.Threading.Tasks;
using TournamentEngine.Core.Common;

namespace Yankee_Team_025
{
    public class Yankee_Team_025Bot : IBot
    {
        public string TeamName => "Yankee_Team_025";
        public GameType GameType => GameType.RPSLS;

        public Task<string> MakeMove(GameState gameState, CancellationToken cancellationToken)
        {
            var moves = new[] { "Rock", "Paper", "Scissors", "Lizard", "Spock" }; return Task.FromResult(moves[gameState.CurrentRound % 5]);
        }

        public Task<int[]> AllocateTroops(GameState gameState, CancellationToken cancellationToken)
        {
            return Task.FromResult(new[] { 20, 20, 20, 20, 20 });
        }

        public Task<string> MakePenaltyDecision(GameState gameState, CancellationToken cancellationToken)
        {
            return Task.FromResult("KickLeft");
        }

        public Task<string> MakeSecurityMove(GameState gameState, CancellationToken cancellationToken)
        {
            return Task.FromResult("Scan");
        }
    }
}
