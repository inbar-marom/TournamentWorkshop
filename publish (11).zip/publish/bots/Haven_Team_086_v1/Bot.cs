
using System.Threading;
using System.Threading.Tasks;
using TournamentEngine.Core.Common;

namespace Haven_Team_086
{
    public class Haven_Team_086Bot : IBot
    {
        public string TeamName => "Haven_Team_086";
        public GameType GameType => GameType.RPSLS;

        public Task<string> MakeMove(GameState gameState, CancellationToken cancellationToken)
        {
            var moves = new[] { "Lizard", "Spock", "Rock", "Paper", "Scissors" }; return Task.FromResult(moves[gameState.CurrentRound % 5]);
        }

        public Task<int[]> AllocateTroops(GameState gameState, CancellationToken cancellationToken)
        {
            return Task.FromResult(new[] { 20, 20, 20, 20, 20 });
        }

        public Task<string> MakePenaltyDecision(GameState gameState, CancellationToken cancellationToken)
        {
            return Task.FromResult("KickLeft");
        }

        public Task<string> MakeSecurityMove(GameState gameState, CancellationToken cancellationToken)
        {
            return Task.FromResult("Scan");
        }
    }
}
