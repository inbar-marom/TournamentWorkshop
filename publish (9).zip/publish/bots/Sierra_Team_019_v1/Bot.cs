
using System.Threading;
using System.Threading.Tasks;
using TournamentEngine.Core.Common;

namespace Sierra_Team_019
{
    public class Sierra_Team_019Bot : IBot
    {
        public string TeamName => "Sierra_Team_019";
        public GameType GameType => GameType.RPSLS;

        public Task<string> MakeMove(GameState gameState, CancellationToken cancellationToken)
        {
            return Task.FromResult("Scissors");
        }

        public Task<int[]> AllocateTroops(GameState gameState, CancellationToken cancellationToken)
        {
            return Task.FromResult(new[] { 20, 20, 20, 20, 20 });
        }

        public Task<string> MakePenaltyDecision(GameState gameState, CancellationToken cancellationToken)
        {
            return Task.FromResult("KickLeft");
        }

        public Task<string> MakeSecurityMove(GameState gameState, CancellationToken cancellationToken)
        {
            return Task.FromResult("Scan");
        }
    }
}
