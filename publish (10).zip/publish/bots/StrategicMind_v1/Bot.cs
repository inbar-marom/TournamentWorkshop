// Bot adapter - wraps UserBot.Core.IBot to work with TournamentEngine.Core.Common.IBot
using TournamentEngine.Core.Common;
using UserBotCore = UserBot.Core;

public class StrategicMind_v1Bot : IBot
{
    private readonly UserBot.StrategicMind.StrategicMindBot _bot = new();

    public string TeamName => "StrategicMind_v1";
    public GameType GameType => GameType.RPSLS;

    public Task<string> MakeMove(GameState gameState, CancellationToken cancellationToken)
    {
        // Convert TournamentEngine GameState to UserBot GameState
        var userBotGameState = new UserBotCore.GameState
        {
            GameType = UserBotCore.GameType.RPSLS,
            RoundNumber = gameState.RoundNumber,
            TotalRounds = gameState.TotalRounds,
            MyMoveHistory = gameState.MyHistory?.ToList() ?? new List<string>(),
            OpponentMoveHistory = gameState.OpponentHistory?.ToList() ?? new List<string>(),
            MyScore = gameState.MyScore,
            OpponentScore = gameState.OpponentScore
        };
        
        return _bot.MakeMove(userBotGameState, cancellationToken);
    }

    public Task<int[]> AllocateTroops(GameState gameState, CancellationToken cancellationToken)
    {
        var userBotGameState = new UserBotCore.GameState
        {
            GameType = UserBotCore.GameType.ColonelBlotto,
            RoundNumber = gameState.RoundNumber,
            TotalRounds = gameState.TotalRounds
        };
        
        return _bot.AllocateTroops(userBotGameState, cancellationToken);
    }

    public Task<string> MakePenaltyDecision(GameState gameState, CancellationToken cancellationToken)
    {
        var userBotGameState = new UserBotCore.GameState
        {
            GameType = UserBotCore.GameType.PenaltyKicks,
            RoundNumber = gameState.RoundNumber,
            TotalRounds = gameState.TotalRounds
        };
        
        // Copy state dictionary
        foreach (var kvp in gameState.State)
        {
            userBotGameState.AdditionalData[kvp.Key] = kvp.Value;
        }
        
        return _bot.MakePenaltyDecision(userBotGameState, cancellationToken);
    }

    public Task<string> MakeSecurityMove(GameState gameState, CancellationToken cancellationToken)
    {
        var userBotGameState = new UserBotCore.GameState
        {
            GameType = UserBotCore.GameType.Security,
            RoundNumber = gameState.RoundNumber,
            TotalRounds = gameState.TotalRounds
        };
        
        // Copy state dictionary
        foreach (var kvp in gameState.State)
        {
            userBotGameState.AdditionalData[kvp.Key] = kvp.Value;
        }
        
        return _bot.MakeSecurityMove(userBotGameState, cancellationToken);
    }
}
