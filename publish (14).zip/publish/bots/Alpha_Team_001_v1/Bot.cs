
using System.Threading;
using System.Threading.Tasks;
using TournamentEngine.Core.Common;

namespace Alpha_Team_001
{
    public class Alpha_Team_001Bot : IBot
    {
        public string TeamName => "Alpha_Team_001";
        public GameType GameType => GameType.RPSLS;

        public Task<string> MakeMove(GameState gameState, CancellationToken cancellationToken)
        {
            return Task.FromResult("Rock");
        }

        public Task<int[]> AllocateTroops(GameState gameState, CancellationToken cancellationToken)
        {
            return Task.FromResult(new[] { 20, 20, 20, 20, 20 });
        }

        public Task<string> MakePenaltyDecision(GameState gameState, CancellationToken cancellationToken)
        {
            return Task.FromResult("KickLeft");
        }

        public Task<string> MakeSecurityMove(GameState gameState, CancellationToken cancellationToken)
        {
            return Task.FromResult("Scan");
        }
    }
}
