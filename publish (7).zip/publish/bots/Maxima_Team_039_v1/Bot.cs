
using System.Threading;
using System.Threading.Tasks;
using TournamentEngine.Core.Common;

namespace Maxima_Team_039
{
    public class Maxima_Team_039Bot : IBot
    {
        public string TeamName => "Maxima_Team_039";
        public GameType GameType => GameType.RPSLS;

        public Task<string> MakeMove(GameState gameState, CancellationToken cancellationToken)
        {
            var moves = new[] { "Spock", "Lizard", "Paper", "Scissors", "Rock" }; return Task.FromResult(moves[gameState.CurrentRound % 5]);
        }

        public Task<int[]> AllocateTroops(GameState gameState, CancellationToken cancellationToken)
        {
            return Task.FromResult(new[] { 20, 20, 20, 20, 20 });
        }

        public Task<string> MakePenaltyDecision(GameState gameState, CancellationToken cancellationToken)
        {
            return Task.FromResult("KickLeft");
        }

        public Task<string> MakeSecurityMove(GameState gameState, CancellationToken cancellationToken)
        {
            return Task.FromResult("Scan");
        }
    }
}
