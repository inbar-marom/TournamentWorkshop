
using System.Threading;
using System.Threading.Tasks;
using TournamentEngine.Core.Common;

namespace Jaguar_Team_036
{
    public class Jaguar_Team_036Bot : IBot
    {
        public string TeamName => "Jaguar_Team_036";
        public GameType GameType => GameType.RPSLS;

        public Task<string> MakeMove(GameState gameState, CancellationToken cancellationToken)
        {
            var moves = new[] { "Paper", "Scissors", "Rock", "Spock", "Lizard" }; return Task.FromResult(moves[gameState.CurrentRound % 5]);
        }

        public Task<int[]> AllocateTroops(GameState gameState, CancellationToken cancellationToken)
        {
            return Task.FromResult(new[] { 20, 20, 20, 20, 20 });
        }

        public Task<string> MakePenaltyDecision(GameState gameState, CancellationToken cancellationToken)
        {
            return Task.FromResult("KickLeft");
        }

        public Task<string> MakeSecurityMove(GameState gameState, CancellationToken cancellationToken)
        {
            return Task.FromResult("Scan");
        }
    }
}
