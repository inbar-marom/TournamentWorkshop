
using System.Threading;
using System.Threading.Tasks;
using TournamentEngine.Core.Common;

namespace Titan_Team_046
{
    public class Titan_Team_046Bot : IBot
    {
        public string TeamName => "Titan_Team_046";
        public GameType GameType => GameType.RPSLS;

        public Task<string> MakeMove(GameState gameState, CancellationToken cancellationToken)
        {
            var moves = new[] { "Scissors", "Rock", "Paper", "Lizard", "Spock" }; return Task.FromResult(moves[gameState.CurrentRound % 5]);
        }

        public Task<int[]> AllocateTroops(GameState gameState, CancellationToken cancellationToken)
        {
            return Task.FromResult(new[] { 20, 20, 20, 20, 20 });
        }

        public Task<string> MakePenaltyDecision(GameState gameState, CancellationToken cancellationToken)
        {
            return Task.FromResult("KickLeft");
        }

        public Task<string> MakeSecurityMove(GameState gameState, CancellationToken cancellationToken)
        {
            return Task.FromResult("Scan");
        }
    }
}
