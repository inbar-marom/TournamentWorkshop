
using System.Threading;
using System.Threading.Tasks;
using TournamentEngine.Core.Common;

namespace Galaxy_Team_033
{
    public class Galaxy_Team_033Bot : IBot
    {
        public string TeamName => "Galaxy_Team_033";
        public GameType GameType => GameType.RPSLS;

        public Task<string> MakeMove(GameState gameState, CancellationToken cancellationToken)
        {
            return Task.FromResult("Spock");
        }

        public Task<int[]> AllocateTroops(GameState gameState, CancellationToken cancellationToken)
        {
            return Task.FromResult(new[] { 20, 20, 20, 20, 20 });
        }

        public Task<string> MakePenaltyDecision(GameState gameState, CancellationToken cancellationToken)
        {
            return Task.FromResult("KickLeft");
        }

        public Task<string> MakeSecurityMove(GameState gameState, CancellationToken cancellationToken)
        {
            return Task.FromResult("Scan");
        }
    }
}
