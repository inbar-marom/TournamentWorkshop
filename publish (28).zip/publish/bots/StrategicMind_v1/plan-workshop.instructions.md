---
description: Always
# applyTo: 'Describe when these instructions should be loaded' # when provided, instructions will automatically be added to the request context when the pattern matches an attached file
---
Must enforce:

Every function must have Unit Tests

Every statement must end with a Two forward slashes(//)

Only classes and functions may contain documentation

No inline comments in the rest of the code