using TournamentEngine.Core.Common;

namespace StarterBot;

/// <summary>
/// Starter bot template - implements all required game methods
/// Customize this bot to implement your own strategies!
/// </summary>
public class MyBot : IBot
{
    public string TeamName => "StarterBot";
    public GameType GameType => GameType.RPSLS; // All bots support all game types

    // RPSLS Game: Choose Rock, Paper, Scissors, Lizard, or Spock
    public Task<string> MakeMove(GameState gameState, CancellationToken cancellationToken)
    {
        // Simple strategy: always play Rock
        // TODO: Implement your own strategy!
        return Task.FromResult("Rock");
    }

    // Colonel Blotto: Distribute 100 troops across 5 battlefields
    public Task<int[]> AllocateTroops(GameState gameState, CancellationToken cancellationToken)
    {
        // Simple strategy: equal distribution
        // TODO: Implement your own strategy!
        return Task.FromResult(new[] { 20, 20, 20, 20, 20 });
    }

    // Penalty Kicks: Choose Left, Center, or Right (9 rounds)
    // Your role (Shooter or Goalkeeper) is in gameState.State["Role"]
    public Task<string> MakePenaltyDecision(GameState gameState, CancellationToken cancellationToken)
    {
        // Simple strategy: always choose Center
        // TODO: Implement your own strategy based on your role!
        return Task.FromResult("Center");
    }

    // Security Game: Attack targets or defend them (5 rounds)
    // Your role (Attacker or Defender) is in gameState.State["Role"]
    public Task<string> MakeSecurityMove(GameState gameState, CancellationToken cancellationToken)
    {
        var role = gameState.State.TryGetValue("Role", out var r) ? r?.ToString() : "Attacker";
        
        if (role == "Attacker")
        {
            // Choose target 0, 1, or 2
            // TODO: Implement your own attack strategy!
            return Task.FromResult("1"); // Attack middle target
        }
        else
        {
            // Distribute 30 defense units across 3 targets
            // Format: "d0,d1,d2" where d0+d1+d2=30
            // TODO: Implement your own defense strategy!
            return Task.FromResult("10,10,10"); // Equal defense
        }
    }
}
