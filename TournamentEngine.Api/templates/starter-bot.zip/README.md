# Starter Bot Template

## Quick Start

1. Customize `StarterBot.cs` with your team name and strategies
2. Test locally using the Tournament Engine
3. Submit via API: `POST /api/bots/submit`

## Game Types

Your bot must implement all 4 game types:

### 1. RPSLS (Rock-Paper-Scissors-Lizard-Spock)
- 10 rounds per match
- Return: "Rock", "Paper", "Scissors", "Lizard", or "Spock"

### 2. Colonel Blotto
- 5 battlefields, 100 total troops
- Return: Array of 5 integers summing to 100

### 3. Penalty Kicks
- 9 rounds per match
- Role in `gameState.State["Role"]`
- As Shooter: Return "Left", "Center", or "Right"
- As Goalkeeper: Return "Left", "Center", or "Right"

### 4. Security Game
- 5 rounds per match
- Role in `gameState.State["Role"]`
- As Attacker: Return "0", "1", or "2" (target index)
- As Defender: Return "d0,d1,d2" (defense allocation summing to 30)

## Tips

- Use `gameState.RoundHistory` for opponent move history
- Use `gameState.CurrentRound` to track progress
- Implement adaptive strategies based on opponent patterns!

Good luck!
